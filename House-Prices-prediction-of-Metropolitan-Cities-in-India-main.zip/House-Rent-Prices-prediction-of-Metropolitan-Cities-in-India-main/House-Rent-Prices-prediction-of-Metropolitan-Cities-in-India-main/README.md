# House-Rent-Prices-prediction-of-Metropolitan-Cities-in-India
I always wondered that how come our complete focus is to improve the accuracy of model in notebooks despite, we never really deployed our model practically. With the same thought, I created my second End to End ML web app to predict Rental price of house for Indian cities using Flask . 
## Key Features include-

* Number of bedrooms
* Number of bathrooms
* Location
* Area
* Furnished Status
## Check live project at : https://house-rental-price-prediction.herokuapp.com/
